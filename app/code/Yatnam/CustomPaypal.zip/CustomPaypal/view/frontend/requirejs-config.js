var config = {

    deps: [
        "knockoutjs/knockout",
        "knockoutjs/knockout-es5",
        "Yatnam_CustomPaypal/js/PaypalJs",
    ]
};
