define([
    'jquery',
    'knockout'
], function ($) {
    'use strict';

    $(document).ready(function () {
        // Check if any radio button is selected on page load
        checkRadioSelection();

        $(window).on('load', function () {
            checkRadioSelection();
        });

        $('.radio').click(function () {
            console.log("change of state");
            checkRadioSelection();
        });

        // Add click event listener to the overlay to show alert
        $('.paypal-overlay').on('click', function () {
            console.log("click");
            if ($('div#cart-totals .shipping').length == 0) {
                alert('Please select a shipping rate.');
            }
        });

        // Function to check if any radio button is selected
        function checkRadioSelection() {
            console.log("checkRadioSelection");

            if ($('div#cart-totals .shipping').length == 0) {
                $('.paypal-overlay').show();
                console.log("show");

            } else {
                $('.paypal-overlay').hide();
                console.log("not show");

            }
        }
    });

});
