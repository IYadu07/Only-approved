<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Yatnam\CustomBanner\Controller\Adminhtml\Category\Image;

use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\ResultFactory;
use Psr\Log\LoggerInterface;

/**
 * Class Upload
 */
class Upload extends \Magento\Backend\App\Action implements HttpPostActionInterface
{
    /**
     * Image uploader
     *
     * @var \Yatnam\CustomBanner\Model\ImageUploader
     */
    // protected $imageUploader;

    /**
     * Logger
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * Upload constructor.
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Yatnam\CustomBanner\Model\ImageUploader $imageUploader
     * @param LoggerInterface $logger
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        // \Yatnam\CustomBanner\Model\ImageUploader $imageUploader,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        // $this->imageUploader = $imageUploader;
        $this->logger = $logger;
    }

    /**
     * Check admin permissions for this controller
     *
     * @return boolean
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Yatnam_CustomBanner::categories');
    }

    /**
     * Upload file controller action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        print_r("hello");
        exit;
        $this->logger->info('Reached the execute function of Upload controller.');

        $imageId = $this->_request->getParam('param_name', 'image_banner');

        try {
            // $result = $this->imageUploader->saveFileToTmpDir($imageId);
        } catch (\Exception $e) {
            $this->logger->error($e->getMessage()); // Log error message
            $result = ['error' => $e->getMessage(), 'errorcode' => $e->getCode()];
        }
        // return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData($result);
    }
}
